#Problem 9

#Programming Language:   Python 3.5.1
#Development Framework:  IDLE
#Platform:               Windows 10


#Instructions:
#run the program and enter d to decrypt or e to encrypt

#for encryption, enter the message(m), public key parts (e) and (n) in that order all 1-space separated
#   the program will return an encrypted message number

#for decryption, enter the ecrypted message(c), private key parts (p),(q), and (d) in that order all 1-space separated
#   the proram will return the decrypted message number, and the public key part (e)

#the program will ask you to press ENTER to exit


#Test Data: (an arrow (->) indicates information that the program prints out or returns)
# e
#1976620216402300889624482718775150 65537 145906768007583323230186939349070635292401872375357164399581871019873438799005358938369571402670149802121818086292467422828157022922076746906543401224889672472407926969987100581290103199317858753663710862357656510507883714297115637342788911463535102712032765166518411726859837988672111837205085526346618740053 
#->
#encrypted message is 35052111338673026690212423937053328511880760811579981620642802346685810623109850235943049080973386241113784040794704193978215378499765413083646438784740952306932534945195080183861574225226218879827232453912820596886440377536082465681750074417459151485407445862511023472235560823053497791518928820272257787786

#e
#123456789 65537 178076698764316482877
#->
#encrypted message is 62022011753771218891

#d
#7533231374898382904174 694420975411 12583867141 7272195257079707781473
#->
#decrypted message is 42
#public key part e is 65537

#d
#4792189117479614137708 694420975411 12583867141 1028058975739840826753
#->
#decrypted message is 77777777777
#public key part e is 17

def modular_multiply(a,b,mod):
    return ((a%mod) * (b%mod)) % mod

def modular_power(a,n,mod):
    y = 1
    v = a % mod
    while n > 0:
        if(n%2 == 1):
            y = (y * v) % mod
        v = (v * v) % mod
        n = n//2
    return y

def gcd(n0, n1):

    if(n1 < n0):
        temp = n1
        n1=n0
        n0=temp
    
    value=n0
    quotient = n1
    remainder= value % quotient

    #coefficients of n_0 and n_1 are stored as a list of 3 because they are
    #independent variables that depend on their own previous values

    coeff_n0 = [0,1]
    coeff_n1 = [1,0]
    coeff_n0.insert(0,coeff_n0[1] - (value // quotient) * coeff_n0[0])
    coeff_n0.pop(-1)
    coeff_n1.insert(0,coeff_n1[1] - (value // quotient) * coeff_n1[0])
    coeff_n1.pop(-1)

    #print("%i = %i * (%i) + %i" % (value, quotient, value // quotient ,remainder), coeff_n0, coeff_n1)

    last_remainder = remainder #a memory variable to remember the second to last remainder

    if(remainder==0):#if value of remainder now is 0 (to prevent modulo by zero error later)
        
        if((n0==1) & (n1==1)):
            
            return 1,0,1

            #n0==1 and n1==1 is a corner case: it is the only two numbers that are equal and have a GCD equal to 1,
            #so we must return 1,0,1 instead of 0,1,1 because otherwise the program will return 0 as the modular inverse, where order would not matter
            
        
        return coeff_n0[1], coeff_n1[1], n1
    

    while(True):

        last_remainder = remainder
        
        value=quotient
        quotient = remainder
        remainder= value % quotient

        coeff_n0.insert(0,coeff_n0[1] - (value // quotient) * coeff_n0[0])
        coeff_n0.pop(-1)
        coeff_n1.insert(0,coeff_n1[1] - (value // quotient) * coeff_n1[0])
        coeff_n1.pop(-1)

        #print("%i = %i * (%i) + %i" % (value, quotient, value // quotient ,remainder), coeff_n0, coeff_n1)

        if(remainder==0):#if the value of the remainder is 0 on the next iteration,
            break

    #return x,y,g such that ax + by = g (x may be negative, is the inverse)
    return coeff_n0[1], coeff_n1[1], last_remainder
    


def RSA(p,q,e):
    n=p*q

    totient = (p-1)*(q-1)

    x,_,g = gcd(e, totient)

    if(g!=1):
        print("invalid numbers: e and totient are not coprime")

    d = x%totient #because x is the inverse mod totient, not guaranteed positive

    #returns public, private key pairs
    return ((n,e),(p,q,d))

def encrypt(n,e,m):
    _,_,g = gcd(m,n)
    if(g!=1):
        print("gcd of message and n is not 1!")
        return
    c = modular_power(m,e,n)
    return c

def decrypt(c,d,p,q):#USING CHINESE REMAINDER THEOREM

    #make q smaller than p
    if(q>p):
        temp = q
        q=p
        p=temp
    

    m1 = modular_power((c % p), d % (p-1), p)
    m2 = modular_power((c % q), d % (q-1), q)

    qinv,_,_ = gcd(q,p)
    qinv %= p

    h = modular_multiply(qinv, m1-m2, p)
    
    m = m2 + h*q
    
    return m

while True:
    inp = input("for encryption enter e, for decryption enter d\n\t")
    if(inp.lower()=="e"):
        inp = input("enter message(m), public key parts (e) and (n) in that order all 1-space separated\n\t")
        m,e,n = int(inp.split(" ")[0]),int(inp.split(" ")[1]),int(inp.split(" ")[2])
        print("encrypted message is " + str(encrypt(n,e,m)))
        break
    elif(inp.lower()=="d"):
        inp = input("enter ecrypted message(c), private key parts (p),(q), and (d) in that order all 1-space separated\n\t")
        c,p,q,d = int(inp.split(" ")[0]),int(inp.split(" ")[1]),int(inp.split(" ")[2]),int(inp.split(" ")[3])
        print("decrypted message is " + str(decrypt(c,d,p,q)))
        e,_,_ = gcd(d, (p-1)*(q-1))
        e%=(p-1)*(q-1)
        print("public key part e is " + str(e))
        break
    else:
        print("unknown command, please try again")

input("Press ENTER to exit")
