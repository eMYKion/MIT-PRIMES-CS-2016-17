#Problem 6

#Programming Language:   Python 3.5.1
#Development Framework:  IDLE
#Platform:               Windows 10

#Instructions: Run the program to get the 
#enter two integers surrounding an operation(+,*,^), and a modulus (everything separated by only one space)
#eg. 5 + 4 6
#The program will find the modular operation of the first number on the second number modulo the modulus number
#The program will then ask you to press ENTER to exit.


#Test Data: (an arrow (->) indicates information that the program prints out or returns)
#5 + 4 6 -> 3
#100000000000000000 + 2000000000000000 9988426849099 -> 8173443850111
#100000000000000000 * 2000000000000000 9988426849099 -> 2784574781170
#100000000000000000 ^ 2000000000000000 9988426849099 -> 1737895540235

def modular_add(a,b,mod):
    return ((a%mod) + (b%mod)) % mod

def modular_multiply(a,b,mod):
    return ((a%mod) * (b%mod)) % mod

def modular_power(a,n,mod):
    y = 1
    v = a % mod
    while n > 0:
        if(n%2 == 1):
            y = (y * v) % mod
        v = (v * v) % mod
        n = n//2
    return y

inp = input("give an input in the for of a <operator> b m,\nwhere a,b,m are integers, and <operator> is +, *, or ^ (1-space separate everything)\n")
a,op,b,m = int(inp.split(" ")[0]),inp.split(" ")[1],int(inp.split(" ")[2]),int(inp.split(" ")[3])

if(op=="+"):
    print(modular_add(a,b,m))
elif(op=="*"):
    print(modular_multiply(a,b,m))
elif(op=="^"):
    print(modular_power(a,b,m))
else:
    print("did not recognize operation, use +,*, or ^ next time")
input("Press ENTER to exit")
