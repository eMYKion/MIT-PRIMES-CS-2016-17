#Problem 7

#Programming Language:   Python 3.5.1
#Development Framework:  IDLE
#Platform:               Windows 10

#Instructions:
#enter two prime numbers and a public key part p,q,e in that order, 1-space separated
#e.g. 10040238757 12604798513 23
#The program will calculate and
#return the complete set of public and private keys for a RSA scheme
#The program will then ask you to press ENTER to exit


#Test Data: (an arrow (->) indicates information that the program prints out or returns)
#10040238757 12604798513 23 ->
#   public: n,e = (126555186554398568341, 23)
#   private: p,q,d = (10040238757, 12604798513, 110047988288481331367)


#10040238757 12604798513 65537 ->
#   public: n,e = (126555186554398568341, 65537)
#   private: p,q,d = (10040238757, 12604798513, 124295858697977929025)

def gcd(n0, n1):
    
    value=n0
    quotient = n1
    remainder= value % quotient

    #coefficients of n_0 and n_1 are stored as a list of 3 because they are
    #independent variables that depend on their own previous values

    coeff_n0 = [0,1]
    coeff_n1 = [1,0]
    coeff_n0.insert(0,coeff_n0[1] - (value // quotient) * coeff_n0[0])
    coeff_n0.pop(-1)
    coeff_n1.insert(0,coeff_n1[1] - (value // quotient) * coeff_n1[0])
    coeff_n1.pop(-1)

    last_remainder = remainder #a memory variable to remember the second to last remainder

    if(remainder==0):#if value of remainder now is 0 (to prevent modulo by zero error later)
        
        if((n0==1) & (n1==1)):
            
            return 1,0,1

            #n0==1 and n1==1 is a corner case: it is the only two numbers that are equal and have a GCD equal to 1,
            #so we must return 1,0,1 instead of 0,1,1 because otherwise the program will return 0 as the modular inverse, where order would not matter
            
        
        return coeff_n0[1], coeff_n1[1], n1
    

    while(True):

        last_remainder = remainder
        
        value=quotient
        quotient = remainder
        remainder= value % quotient

        coeff_n0.insert(0,coeff_n0[1] - (value // quotient) * coeff_n0[0])
        coeff_n0.pop(-1)
        coeff_n1.insert(0,coeff_n1[1] - (value // quotient) * coeff_n1[0])
        coeff_n1.pop(-1)

        if(remainder==0):#if the value of the remainder is 0 on the next iteration,
            break

    #return x,y,g such that ax + by = g (x may be negative)
    return coeff_n0[1], coeff_n1[1], last_remainder


def RSA(p,q,e):
    n=p*q

    totient = (p-1)*(q-1)

    x,_,g = gcd(e, totient)

    if(g!=1):
        print("invalid numbers: e and totient are not coprime")

    d = x%totient #because x is the inverse mod totient, not guaranteed positive

    #returns public, private key pairs
    return ((n,e),(p,q,d))
    


inp = input("enter p,q,e (in that order, 1-space separated) ")
p,q,e=int(inp.split(" ")[0]),int(inp.split(" ")[1]),int(inp.split(" ")[2])

public, private = RSA(p,q,e)

print("key pairs generated:\n\tpublic: " + str(public) + "\n\tprivate: " + str(private))
input("Press ENTER to exit")

