#Problem 13

#Programming Language:   Python 3.5.1
#Development Framework:  IDLE
#Platform:               Windows 10


#Instructions:
#Run the program and enter s to digitally sign or v to digitall verify

#For digitally signing, enter message(m), private key parts (p),(q),and(d) in that order all 1-space separated
#the program will return the "encrypted" digital signature

#For digitally verifying, enter digital signature(c), message (m), and public key parts (e) and (n) in that order all 1-space separated
#the program will return True if the digital verification is valid, or False if not

#the program will ask you to press ENTER to exit


#Test Data: (an arrow (->) indicates information that the program prints out or returns)

#v
#111889714168449968140 12345 65537 178076698764316482877
#->
#digital verification returns True

#v
#68295009307484396257 54321 65537 178076698764316482877
#->
#digital verification returns False

def modular_multiply(a,b,mod):
    return ((a%mod) * (b%mod)) % mod

def modular_power(a,n,mod):
    y = 1
    v = a % mod
    while n > 0:
        if(n%2 == 1):
            y = (y * v) % mod
        v = (v * v) % mod
        n = n//2
    return y


def digital_sign(m, p, q, d):
    signature = modular_power(m,d,p*q)
    return signature

def digital_verify(c, m, e, n):
    m_guess = modular_power(c,e,n)

    return m_guess==m

while True:
    inp = input("to digitally sign enter s, to digitally verify enter v\n\t")
    if(inp.lower()=="s"):
        inp = input("enter message(m), private key parts (p),(q),and(d) in that order all 1-space separated\n\t")
        m,p,q,d = int(inp.split(" ")[0]),int(inp.split(" ")[1]),int(inp.split(" ")[2]),int(inp.split(" ")[3])
        print("digital signature is " + str(digital_sign(m,p,q,d)))
        break
    elif(inp.lower()=="v"):
        inp = input("enter digital signature(c), message (m), and public key parts (e) and (n) in that order all 1-space separated\n\t")
        c,m,e,n = int(inp.split(" ")[0]),int(inp.split(" ")[1]),int(inp.split(" ")[2]),int(inp.split(" ")[3])
        print("digital verification returns " + str(digital_verify(c,m,e,n)))
        break
    else:
        print("unknown command, please try again")

input("Press ENTER to exit")
    
    

