#problem 4

#extended euclidean algorithm

#Programming Language:   Python 3.5.1
#Development Framework:  IDLE
#Platform:               Windows 10

#Instructions: Run the program and it will prompt "enter two numbers "
#Enter the first and second numbers (integers larger than 0) separated by one space only
#The program will find the greatest common divisor between the two integers
#The program will then ask you to press ENTER to exit.

#Test Data: (an arrow (->) indicates information that the program prints out or returns)
#GCD of 82243497 and 372233247 is 3
#GCD of 1530864174490193 and 1324693829967097 is 98496421
#GCD of 3478169421466939 and 18237769603176901 is 1



def gcd(n0, n1):

    #sort n0 and n1 in increasing order for mathematical convenience
    if(n1>n0):
        temp=n0
        n0=n1
        n1=temp
    
    value=n0
    quotient = n1
    remainder= value % quotient

    last_remainder = remainder #a memory variable to remember the second to last remainder

    print("%i = %i * (%i) + %i" % (value, quotient, value // quotient ,remainder))

    if(remainder==0):#if value of remainder is 0 on first iteration
        print("the greatest common divisor of %i and %i is %i" % (n0, n1, n1))
        return

    while(True):
        last_remainder = remainder
        
        value=quotient
        quotient = remainder
        remainder= value % quotient
        
        print("%i = %i * (%i) + %i" % (value, quotient, value // quotient ,remainder))

        if(remainder==0):#if the value of the remainder is 0 
            break
        

            
        
    print("the greatest common divisor of %i and %i is %i" % (n0, n1, last_remainder))


inp = input("enter two numbers ")
split = inp.split(" ")

gcd(int(split[0]), int(split[1]))

input("Press ENTER to exit")

