#problem 5

#multiplicative inverse of a mod m

#Programming Language:   Python 3.5.1
#Development Framework:  IDLE
#Platform:               Windows 10

#Instructions: Run the program and it will prompt "enter two numbers "
#Enter the first and second numbers (integers larger than 0) separated by one space only (second number must be larger than first as input)
#The program will find the multiplicative inverse of the first number modulo the second number 
#the program will say that no multiplicative inverse exists if the numbers are not coprime
#The program will then ask you to press ENTER to exit.


#Test Data: (an arrow (->) indicates information that the program prints out or returns)
#The multiplicative inverse of 7 mod 12 is 7.
#7 12 -> 7

#The multiplicative inverse of 3 mod 9988426849099 is 6658951232733.
#3 9988426849099 -> 6658951232733

#The multiplicative inverse of 65537 mod 9988426849099 is 5879176124998.
#65537 9988426849099 -> 5879176124998


def gcd(n0, n1):
    
    value=n0
    quotient = n1
    remainder= value % quotient

    #coefficients of n_0 and n_1 are stored as a list of 3 because they are
    #independent variables that depend on their own previous values

    coeff_n0 = [0,1]
    coeff_n1 = [1,0]
    coeff_n0.insert(0,coeff_n0[1] - (value // quotient) * coeff_n0[0])
    coeff_n0.pop(-1)
    coeff_n1.insert(0,coeff_n1[1] - (value // quotient) * coeff_n1[0])
    coeff_n1.pop(-1)

    print("%i = %i * (%i) + %i" % (value, quotient, value // quotient ,remainder), coeff_n0, coeff_n1)

    last_remainder = remainder #a memory variable to remember the second to last remainder

    if(remainder==0):#if value of remainder now is 0 (to prevent modulo by zero error later)
        
        if((n0==1) & (n1==1)):
            
            return 1,0,1

            #n0==1 and n1==1 is a corner case: it is the only two numbers that are equal and have a GCD equal to 1,
            #so we must return 1,0,1 instead of 0,1,1 because otherwise the program will return 0 as the modular inverse, where order would not matter
            
        
        return coeff_n0[1], coeff_n1[1], n1
    

    while(True):

        last_remainder = remainder
        
        value=quotient
        quotient = remainder
        remainder= value % quotient

        coeff_n0.insert(0,coeff_n0[1] - (value // quotient) * coeff_n0[0])
        coeff_n0.pop(-1)
        coeff_n1.insert(0,coeff_n1[1] - (value // quotient) * coeff_n1[0])
        coeff_n1.pop(-1)

        print("%i = %i * (%i) + %i" % (value, quotient, value // quotient ,remainder), coeff_n0, coeff_n1)

        if(remainder==0):#if the value of the remainder is 0 on the next iteration,
            break
        
    return coeff_n0[1], coeff_n1[1], last_remainder


inp = input("enter two increasing numbers ")
a,m = int(inp.split(" ")[0]), int(inp.split(" ")[1])

x,y,g = gcd(a, m)
print("GCD is " + str(g))

print("%i * (%i) + %i * (%i) = %i" % (a,x,m,y,g))

if(g!=1):
    print("no multiplicative inverse exists for %s (mod %s)" % (a, m))
else:
    if(x<0):
        x%=m
    print("the multiplicative inverse for %s (mod %s) is %i" % (a, m, x))
    print("%s * %i = 1 (mod %s)" % (a, x, m))

input("Press ENTER to exit")
