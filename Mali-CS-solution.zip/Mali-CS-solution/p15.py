#Problem 15

#Programming Language:   Python 3.5.1
#Development Framework:  IDLE
#Platform:               Windows 10


#Instructions:
#Run the program and enter
#a message (m) and private key (p), (q), (d) in that order all 1-space separated
#The program will print step-by-step the procedure for blind verification
#the program will ask you to press ENTER to exit

#NOTE: the program uses a procedurally generated random variable so
#the intermediate numbers in the example below are not necessarily what you
#would get as an output, but the message will still verify in the end


#Test Data: (an arrow (->) indicates information that the program prints out or returns)
#33333333333 694420975411 12583867141 7272195257079707781473
#->
#public key (e,n) is (65537, 8738501294495651869951)
#small random number r is 8527
#Alice sends m_b = m*r^e = 2270162521529466108635 (mod n)to Bob 
#Bob signs and sends s_b = m_b^d = 7126181473280241941023 (mod n) to Alice
#r_inv is 5199854059841789326625
#m_guess (33333333333) ?= m (33333333333)
#Alice checks if (s_b*r_inv)^e == m (mod n)
#message is verified

from random import randint

def modular_multiply(a,b,mod):
    return ((a%mod) * (b%mod)) % mod

def modular_power(a,n,mod):
    y = 1
    v = a % mod
    while n > 0:
        if(n%2 == 1):
            y = (y * v) % mod
        v = (v * v) % mod
        n = n//2
    return y

def gcd(n0, n1):

    if(n1 < n0):
        temp = n1
        n1=n0
        n0=temp
    
    value=n0
    quotient = n1
    remainder= value % quotient

    #coefficients of n_0 and n_1 are stored as a list of 3 because they are
    #independent variables that depend on their own previous values

    coeff_n0 = [0,1]
    coeff_n1 = [1,0]
    coeff_n0.insert(0,coeff_n0[1] - (value // quotient) * coeff_n0[0])
    coeff_n0.pop(-1)
    coeff_n1.insert(0,coeff_n1[1] - (value // quotient) * coeff_n1[0])
    coeff_n1.pop(-1)

    #print("%i = %i * (%i) + %i" % (value, quotient, value // quotient ,remainder), coeff_n0, coeff_n1)

    last_remainder = remainder #a memory variable to remember the second to last remainder

    if(remainder==0):#if value of remainder now is 0 (to prevent modulo by zero error later)
        
        if((n0==1) & (n1==1)):
            
            return 1,0,1

            #n0==1 and n1==1 is a corner case: it is the only two numbers that are equal and have a GCD equal to 1,
            #so we must return 1,0,1 instead of 0,1,1 because otherwise the program will return 0 as the modular inverse, where order would not matter
            
        
        return coeff_n0[1], coeff_n1[1], n1
    

    while(True):

        last_remainder = remainder
        
        value=quotient
        quotient = remainder
        remainder= value % quotient

        coeff_n0.insert(0,coeff_n0[1] - (value // quotient) * coeff_n0[0])
        coeff_n0.pop(-1)
        coeff_n1.insert(0,coeff_n1[1] - (value // quotient) * coeff_n1[0])
        coeff_n1.pop(-1)

        #print("%i = %i * (%i) + %i" % (value, quotient, value // quotient ,remainder), coeff_n0, coeff_n1)

        if(remainder==0):#if the value of the remainder is 0 on the next iteration,
            break

    #return x,y,g such that ax + by = g (x may be negative, is the inverse)
    return coeff_n0[1], coeff_n1[1], last_remainder

def blind_message(m, r, e, n):
    
    b_message = modular_multiply(m, modular_power(r, e, n), n)

    return b_message

def blind_sign(b_message, d, n):

    b_sign = modular_power(b_message, d, n)
    
    return b_sign

def verify(b_sign, m, r, e, n):
    
    r_inv,_,g = gcd(r, n)
    r_inv%=n
    print("r_inv is %i" % r_inv)
    if(g!=1):
        print("signed blind signature and n are not coprime")

    m_guess = modular_power(modular_multiply(b_sign, r_inv, n), e, n)
    print("m_guess (%i) ?= m (%i)"% (m_guess, m))
    
    return m_guess == m

def show_blind_signature(m, p, q, d):
    
    n = p*q
    
    e,_,g = gcd(d, (p-1)*(q-1))
    e%=((p-1)*(q-1))

    if(g!=1):
        print("d and totient are not coprime")

    print("public key (e,n) is (%i, %i)" % (e,n))

    r = randint(10,10001)
    print("small random number r is " + str(r))

    #Alice sends to Bob
    m_blind = blind_message(m, r, e, n)
    print("Alice sends m_b = m*r^e = %i (mod n)to Bob " % (m_blind))
    

    #Bob sends back to Alice
    s_blind = blind_sign(m_blind, d, n)
    print("Bob signs and sends s_b = m_b^d = %i (mod n) to Alice" % (s_blind))

    #Alice computes
    ver = verify(s_blind, m, r, e, n)
    print("Alice checks if (s_b*r_inv)^e == m (mod n)")

    if(ver):
        print("message is verified")
    else:
        print("message is not verified")

    
inp = input("enter a message (m) and private key (p), (q), (d) in that order all 1-space separated\n\t")
m,p,q,d = int(inp.split(" ")[0]),int(inp.split(" ")[1]),int(inp.split(" ")[2]),int(inp.split(" ")[3])

show_blind_signature(m,p,q,d)
input("press ENTER to exit")
