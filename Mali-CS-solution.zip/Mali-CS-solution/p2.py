from math import sqrt, ceil
from time import time

#problem 2

#Programming Language:   Python 3.5.1
#Development Framework:  IDLE
#Platform:               Windows 10

#Instructions: Run the program and it will prompt "enter a number ".
#Simply enter the integer to find if it is prime or not.
#If the number's smallest prime factor is large,
#the program will log the slowest possible progress (where 1.0 is complete) as it computes the answer.
#The program will tell you if the number is prime or not (in words) and its smallest factor (if not prime).
#The program will give you the time in seconds it took to solve the particular number.
#The program will then ask you to press ENTER to exit.

#Test Data: (an arrow (->) indicates information that the program prints out or returns)
#101 -> prime
#5   -> prime
#6   -> not prime

#58148527 -> prime
#665999921 -> prime
#1558438050556301 -> Probably not prime (took a VERY long time)

#665999933 -> prime (is larger than) 665999921

primes=[2]
start_time=0

def isPrime(num):

    #the largest prime factor of a number is its square root[SOURCE]

    upper_limit = ceil(sqrt(num))
    
    latestPrime = primes[-1]

    prog_cycle=0

    while((upper_limit>latestPrime) & ((num%latestPrime)!=0)):

        latestPrime+=1
        
        for idx in range(0,len(primes)):
            
            if(latestPrime%primes[idx]==0):
                
                break
            
            elif(idx == len(primes)-1):
                
                    primes.append(latestPrime)
                    prog_cycle+=1
                    if(prog_cycle%200==0):
                        print("slowest progress: " + str(latestPrime/float(upper_limit)))

        
		
    if((num%latestPrime)==0):
        print(str(num) + "%i is not prime, smallest factor is %i \nsolved in %.5f seconds" % (num, latestPrime, time()-start_time))
        return None
    else:
        print("%i is prime!\nsolved in %.5f seconds" % (num, time()-start_time))
        return None

number = int(input("enter a number "))
start_time=time()
isPrime(number)
input("press ENTER to exit")
